from app_pinturas import app
from app_pinturas.controladores import controlador_usuarios, controlador_pinturas

if __name__=="__main__":
    app.run(debug=True)