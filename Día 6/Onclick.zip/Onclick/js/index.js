console.log("correcto"); 

function mensaje(elemento){
    elemento.innerHTML="Logout";
}
/*Listo!*/
function alertaclick(){
    alert("Ninja was liked");
}

function ocultarBoton(elemento) {
    elemento.remove();
}